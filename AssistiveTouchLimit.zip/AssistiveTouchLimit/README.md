# Assistive Touch (Drag Limit)

Kotlin + Jetpack Compose + MVVM, min SDK 28.

Floating overlay button with a configurable upward drag limit, soft resistance zone,
snap-to-edge and return-to-start. Uses only finger movement; no screen reading.

## Build
Android Studio: File > Open this folder, let Gradle sync, then Build > Build APK(s).
(Android Studio generates the Gradle wrapper automatically.)

GitHub Actions: push to a repo; .github/workflows/build.yml builds app-debug.apk
and uploads it as an artifact.

## First run
Open the app, tap the big button, allow "Display over other apps", come back and tap again.
