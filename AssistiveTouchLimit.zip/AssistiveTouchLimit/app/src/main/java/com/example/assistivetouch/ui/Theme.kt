package com.example.assistivetouch.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF0A84FF)
val Panel = Color(0xFF1C1C1E)
val PanelHigh = Color(0xFF2C2C2E)
val Muted = Color(0xFF8E8E93)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Color.Black,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White,
        ),
        content = content
    )
}
