package com.example.assistivetouch

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepo(app)
    private val _state = MutableStateFlow(repo.load())
    val state: StateFlow<Settings> = _state

    fun update(change: (Settings) -> Settings) {
        val next = change(_state.value)
        _state.value = next
        repo.save(next)
    }
}
