package com.example.assistivetouch.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assistivetouch.DragLimiter
import com.example.assistivetouch.Settings
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    settings: Settings,
    running: Boolean,
    hasOverlayPermission: Boolean,
    onGrantOverlay: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onChange: ((Settings) -> Settings) -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Assistive Touch", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Floating button with drag control", color = Muted)

        PowerCard(running, hasOverlayPermission, onGrantOverlay, onToggle)

        SectionPanel("Live preview") { DragPreview(settings) }

        SectionPanel("Drag limit") {
            SwitchRow("Limit upward drag", "Stops the button at a set distance above where you started", settings.limitEnabled) { v ->
                onChange { it.copy(limitEnabled = v) }
            }
            SliderRow("Max distance up", "${settings.maxUpDp.roundToInt()} dp", settings.maxUpDp, 40f..300f, settings.limitEnabled) { v ->
                onChange { it.copy(maxUpDp = v, softZoneDp = it.softZoneDp.coerceAtMost(v)) }
            }
            SliderRow("Soft zone", "${settings.softZoneDp.roundToInt()} dp", settings.softZoneDp, 0f..settings.maxUpDp, settings.limitEnabled) { v ->
                onChange { it.copy(softZoneDp = v) }
            }
        }

        SectionPanel("Button") {
            SliderRow("Size", "${settings.sizeDp.roundToInt()} dp", settings.sizeDp, 40f..100f, true) { v ->
                onChange { it.copy(sizeDp = v) }
            }
            SliderRow("Opacity", "${(settings.opacity * 100).roundToInt()}%", settings.opacity, 0.3f..1f, true) { v ->
                onChange { it.copy(opacity = v) }
            }
            SwitchRow("Snap to edge", "Slides to the nearest side when released", settings.snapToEdge) { v ->
                onChange { it.copy(snapToEdge = v, returnToStart = if (v) false else it.returnToStart) }
            }
            SwitchRow("Return to start", "Jumps back to where the drag began", settings.returnToStart) { v ->
                onChange { it.copy(returnToStart = v, snapToEdge = if (v) false else it.snapToEdge) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PowerCard(
    running: Boolean,
    hasPermission: Boolean,
    onGrant: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                if (running) Brush.linearGradient(listOf(Color(0xFF0A84FF), Color(0xFF5E5CE6)))
                else Brush.linearGradient(listOf(PanelHigh, Panel))
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(if (running) Color.White else Color(0xFF3A3A3C))
                .clickable { if (hasPermission) onToggle(!running) else onGrant() },
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (running) "ON" else "OFF",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = if (running) Blue else Color.White
            )
        }
        Text(
            when {
                !hasPermission -> "Tap to allow display over other apps"
                running -> "Floating button is active"
                else -> "Tap to show the floating button"
            },
            color = Color.White,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun SectionPanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Panel)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(title.uppercase(), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        content()
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(
            checked = value, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Blue)
        )
    }
}

@Composable
private fun SliderRow(
    title: String, valueText: String, value: Float,
    range: ClosedFloatingPointRange<Float>, enabled: Boolean, onChange: (Float) -> Unit
) {
    Column(Modifier.alpha(if (enabled) 1f else 0.4f)) {
        Row {
            Text(title, color = Color.White, modifier = Modifier.weight(1f))
            Text(valueText, color = Blue, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value.coerceIn(range), onValueChange = onChange,
            valueRange = range, enabled = enabled,
            colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue)
        )
    }
}

/** Try the limit right here: drag the button up and feel the soft zone and stop. */
@Composable
private fun DragPreview(s: Settings) {
    val d = LocalDensity.current.density
    var total by remember { mutableStateOf(Offset.Zero) }
    val sizePx = s.sizeDp * d
    val maxUpPx = s.maxUpDp * d
    val limitedY = if (s.limitEnabled) DragLimiter.limitUp(total.y, maxUpPx, s.softZoneDp * d) else total.y

    Box(
        Modifier
            .fillMaxWidth()
            .height((s.maxUpDp.coerceAtLeast(120f) + 120f).dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .border(1.dp, PanelHigh, RoundedCornerShape(16.dp))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            if (s.limitEnabled) {
                val y = size.height - 60.dp.toPx() - sizePx / 2 - maxUpPx
                drawLine(
                    Blue, Offset(0f, y), Offset(size.width, y), 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))
                )
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp)
                .offset { IntOffset(total.x.roundToInt(), limitedY.roundToInt()) }
                .size(s.sizeDp.dp)
                .clip(CircleShape)
                .background(Panel.copy(alpha = s.opacity))
                .border(3.dp, Blue, CircleShape)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { total = Offset.Zero },
                        onDragEnd = { total = Offset.Zero },
                        onDragCancel = { total = Offset.Zero }
                    ) { change, drag ->
                        change.consume()
                        total += drag
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size((s.sizeDp / 2).dp).clip(CircleShape).background(Color.White))
        }
    }
}
