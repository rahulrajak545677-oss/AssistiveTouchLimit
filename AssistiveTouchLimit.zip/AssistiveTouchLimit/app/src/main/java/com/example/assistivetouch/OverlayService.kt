package com.example.assistivetouch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import kotlinx.coroutines.flow.MutableStateFlow

class OverlayService : Service() {

    companion object {
        val running = MutableStateFlow(false)
        private const val CHANNEL = "overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var repo: SettingsRepo
    private var root: View? = null
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> rebuild() }

    private var posX = 40
    private var posY = 400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (root == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            repo = SettingsRepo(this)
            startForeground(1, buildNotification())
            repo.prefs.registerOnSharedPreferenceChangeListener(listener)
            rebuild()
            running.value = true
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_LOW)
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Assistive Touch is running")
            .setContentText("Floating button is active")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
    }

    private fun rebuild() {
        root?.let { runCatching { wm.removeView(it) } }
        val s = repo.load()
        val d = resources.displayMetrics.density
        val size = (s.sizeDp * d).toInt()

        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#CC1C1C1E"))
            setStroke((3 * d).toInt(), Color.parseColor("#0A84FF"))
        }
        val dot = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
        }
        val v = FrameLayout(this).apply {
            background = ring
            alpha = s.opacity
            addView(View(context).apply { background = dot }, FrameLayout.LayoutParams(size / 2, size / 2, Gravity.CENTER))
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = posX; y = posY
        }

        var startX = 0; var startY = 0
        var downX = 0f; var downY = 0f
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    var dy = e.rawY - downY
                    if (s.limitEnabled) {
                        dy = DragLimiter.limitUp(dy, s.maxUpDp * d, s.softZoneDp * d)
                    }
                    lp.x = (startX + dx).toInt()
                    lp.y = (startY + dy).toInt()
                    wm.updateViewLayout(view, lp)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    if (s.returnToStart) {
                        lp.x = startX; lp.y = startY
                    } else if (s.snapToEdge) {
                        val w = resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + size / 2 < w / 2) 0 else w - size
                    }
                    posX = lp.x; posY = lp.y
                    wm.updateViewLayout(view, lp)
                }
            }
            true
        }
        wm.addView(v, lp)
        root = v
    }

    override fun onDestroy() {
        repo.prefs.unregisterOnSharedPreferenceChangeListener(listener)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        running.value = false
        super.onDestroy()
    }
}
