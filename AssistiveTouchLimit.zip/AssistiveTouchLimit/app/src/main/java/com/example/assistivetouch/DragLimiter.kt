package com.example.assistivetouch

import kotlin.math.exp
import kotlin.math.min

/** Pure input math: uses only how far the finger moved. No screen reading. */
object DragLimiter {
    /**
     * @param dy total vertical finger travel since drag start (negative = up)
     * @param maxUp hard limit of upward travel
     * @param soft length of the resistance zone before the limit
     */
    fun limitUp(dy: Float, maxUp: Float, soft: Float): Float {
        val up = -dy
        if (up <= 0f) return dy
        val s = (maxUp - soft).coerceAtLeast(0f)
        if (soft <= 0f || up <= s) return -min(up, maxUp)
        val extra = up - s
        val eased = s + soft * (1f - exp(-extra / soft))
        return -min(eased, maxUp)
    }
}
