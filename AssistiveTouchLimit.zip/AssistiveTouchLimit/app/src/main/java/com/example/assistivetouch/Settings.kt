package com.example.assistivetouch

import android.content.Context
import android.content.SharedPreferences

data class Settings(
    val limitEnabled: Boolean = true,
    val maxUpDp: Float = 120f,
    val softZoneDp: Float = 40f,
    val sizeDp: Float = 64f,
    val opacity: Float = 0.9f,
    val snapToEdge: Boolean = false,
    val returnToStart: Boolean = false,
)

class SettingsRepo(context: Context) {
    val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("at_prefs", Context.MODE_PRIVATE)

    fun load() = Settings(
        limitEnabled = prefs.getBoolean("limit", true),
        maxUpDp = prefs.getFloat("maxUp", 120f),
        softZoneDp = prefs.getFloat("soft", 40f),
        sizeDp = prefs.getFloat("size", 64f),
        opacity = prefs.getFloat("opacity", 0.9f),
        snapToEdge = prefs.getBoolean("snap", false),
        returnToStart = prefs.getBoolean("return", false),
    )

    fun save(s: Settings) {
        prefs.edit()
            .putBoolean("limit", s.limitEnabled)
            .putFloat("maxUp", s.maxUpDp)
            .putFloat("soft", s.softZoneDp.coerceAtMost(s.maxUpDp))
            .putFloat("size", s.sizeDp)
            .putFloat("opacity", s.opacity)
            .putBoolean("snap", s.snapToEdge)
            .putBoolean("return", s.returnToStart)
            .apply()
    }
}
