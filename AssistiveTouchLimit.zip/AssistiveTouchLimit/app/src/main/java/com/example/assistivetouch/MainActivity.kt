package com.example.assistivetouch

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.assistivetouch.ui.AppTheme
import com.example.assistivetouch.ui.HomeScreen

class MainActivity : ComponentActivity() {
    private var hasOverlay by mutableStateOf(false)

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            AppTheme {
                val vm: SettingsViewModel = viewModel()
                val settings by vm.state.collectAsStateWithLifecycle()
                val running by OverlayService.running.collectAsStateWithLifecycle()
                HomeScreen(
                    settings = settings,
                    running = running,
                    hasOverlayPermission = hasOverlay,
                    onGrantOverlay = {
                        startActivity(
                            Intent(
                                AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    },
                    onToggle = { on ->
                        val i = Intent(this, OverlayService::class.java)
                        if (on) startForegroundService(i) else stopService(i)
                    },
                    onChange = vm::update
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hasOverlay = AndroidSettings.canDrawOverlays(this)
    }
}
